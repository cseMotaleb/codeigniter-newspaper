<?php
$cover_image = get_rows(array("table" => "media", "limit" => 1), array("type" => "Slider Image"));
$cover_image = (isset($cover_image['id']) && file_exists("./{$cover_image['url']}")) ? base_url() . "{$cover_image['url']}" : base_url() . "img/cover.png";
?>
<nav class="navbar navbar-default">
<div class="container">

<!-- BRAND -->
<div class="navbar-header">
<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#alignment-example" aria-expanded="false">
<span class="sr-only">Toggle navigation</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand" href="<?= base_url(); ?>"> <img class="logo" alt="Logo" src="<?= $cover_image; ?>"/> </a>
</div>

<!-- COLLAPSIBLE NAVBAR -->
<div class="collapse navbar-collapse" id="alignment-example">

<!-- Links -->
<ul class="nav navbar-nav">
	<?php
		$i = 0;
		$current_cat = "";
		$list_category = array();
		foreach ($categories as $key => $category) :
		//if($i == 0) { $list_category = $category['parent']; $current_cat = $category['category_url']; }
		if(isset($category_data['id']) && ($category_data['id'] == $category['id'])) { $list_category = $category['parent']; /*$current_cat = $category['category_url'];*/ }
		$url = site_url("category/{$category['category_url']}");
		$total_parent = count($category['parent']);
	?>
	<?php if($total_parent > 0) :?>
		
	 	<li class="dropdown">
	      	<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?= $category['category']; ?><span class="caret"></span></a>
	        <ul class="dropdown-menu">
	        	<!-- <li><a href="<?= $url; ?>"><?= $category['category']; ?></a></li> -->
	        	<?php
				foreach ($category['parent'] as $key => $parent) :
					$url = site_url("category/{$category['category_url']}/{$parent['category_url']}");
				?>
	            <li><a href="<?= $url; ?>"><?= $parent['category']; ?></a></li>
	        	<?php endforeach;?>
	        </ul>
	    </li>
	<?php else : ?>
		<li><a href="<?= $url; ?>"><?= $category['category']; ?></a></li>

	<?php endif;?>
    <?php endforeach;?>
    
</ul>

<!-- Search -->
<form class="navbar-form navbar-right" role="search">
<div class="form-group">
<input type="text" class="form-control">
</div>
<button type="submit" class="btn btn-default">Search</button>
</form>

</div>

</div>
</nav>




<script>
 	$(window).load(function(){
  		$(".sticker-menu").sticky({ topSpacing: 0, center:true, className:"hey-menu" });
	});

	 
</script>
